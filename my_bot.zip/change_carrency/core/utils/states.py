from aiogram.fsm.state import State, StatesGroup

class Steps(StatesGroup):
    get_time = State()
    get_sender = State()
    get_time = State()