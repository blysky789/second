import sqlite3 as sql3
import aiogram
import asyncio


#-----add_parse_data to db
async def sql_add_pars_data(id_bank, buy, sale):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        cur.execute(f"insert into ptable values ({id_bank}, {buy}, {sale}) "\
             f" on conflict (id_bank) "\
             f"do update set id_bank  = excluded.id_bank, buy = excluded.buy, sale = excluded.sale;" )
        db.commit()

#-----up_data_from_table
#up_nbu_data
async def sql_up_nbu_data(id_bank, buy, sale):
        a = await up_nbu_data_b(id_bank, buy)
        b = await up_nbu_data_s(id_bank, sale)
        return [a, b]

async def up_nbu_data_b(id_bank, buy):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {buy} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_nbu_buy = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_nbu_buy
    
async def up_nbu_data_s(id_bank, sale):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {sale} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_nbu_sale = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_nbu_sale
          
#up_pb_data
async def sql_up_pb_data(id_bank, buy, sale):
        c = await up_pb_data_b(id_bank, buy)
        d = await up_pb_data_s(id_bank, sale)
        return [c, d]

async def up_pb_data_b(id_bank, buy):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {buy} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_pb_buy = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_pb_buy      
    
async def up_pb_data_s(id_bank, sale):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {sale} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_pb_sale = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_pb_sale
    
#up_point_data
async def sql_up_point_data(id_bank, buy, sale):
        c = await up_point_data_b(id_bank, buy)
        d = await up_point_data_s(id_bank, sale)
        return [c, d]

async def up_point_data_b(id_bank, buy):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {buy} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_point_buy = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_point_buy     
    
async def up_point_data_s(id_bank, sale):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {sale} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_point_sale = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_point_sale

#up_sens_data
async def sql_up_sens_data(id_bank, buy, sale):
        c = await up_sens_data_b(id_bank, buy)
        d = await up_sens_data_s(id_bank, sale)
        return [c, d]

async def up_sens_data_b(id_bank, buy):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {buy} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_sens_buy = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_sens_buy   

async def up_sens_data_s(id_bank, sale):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f'select {sale} from ptable where id_bank = {id_bank};').fetchall()
        b = str(a[0])
        b1 = float(b[1:-2])
        up_res_sens_sale = float('{:.1f}'.format(b1))
        db.commit()
        return up_res_sens_sale




#----- add all users to table
async def sqladdallusers(id, bot, fn, ln, un, lan):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS ptable (user_id INTEGER PRIMARY KEY AUTOINCREMENT, bot TEXT, f_name TEXT, \
                    l_name TEXT, uname TEXT, lang TEXT)")
        cur.execute(f"insert into allusers (user_id, bot, f_name, l_name, uname, lang) \
                        values ({id}, '{bot}', '{fn}', '{ln}', '{un}', '{lan}') on conflict (user_id) do nothing") 
        db.commit()
        print('\nUSER add to DB SQL allusers')



#-----add sender metods to table
# add status waiting to TIME metod
async def sqladdtimemetod(id, time, status):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        cur.execute(f"insert into sender (id, every, status) values ({id}, {time}, '{status}') on conflict (id) do nothing") 
        db.commit()
        print('\nSET data to DB on TIME metod')

#add data to EVERY metod
async def sqladdeverymetod(id, every): 
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        cur.execute(f"insert into sender (id, every) values ({id}, {every}) on conflict (id) do nothing") 
        db.commit()
        print('\nSET data to DB on EVERY metod')

#-----add user lists
    # get EVERY user list
async def sqlupeverylist():
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f"select id from sender where every = '99';").fetchall()
        db.commit()
        return [x[0] for x in a]
        
    
# get TIME user list
async def sqluptimelist(t_val):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        a = cur.execute(f"select id from sender where time = {t_val} and status = 'waiting';").fetchall()
        db.commit()
        return [x[0] for x in a]
    

#----- update status
# update status TIME users to SEND
async def sqlupdatesendtime(id_t):
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        cur.execute(f"update sender set status = 'send' where id = {id_t}")
        db.commit()
        print('\nUPDATE TIME metod to SEND\n')

# update status TIME users to WAITING
async def updatewaitingtime():
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        cur.execute(f"update sender set status = 'waiting' where time >= 0;")
        db.commit()
        print('\nUPDATE TIME metod to WAITING\n')