import aiogram
import asyncpg
import asyncio
import time
from aiogram.exceptions import TelegramRetryAfter
from aiogram import Bot, Dispatcher
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from datetime import datetime
# from core.utils.dbconnect import DbRequests
from aiogram.methods.send_message import SendMessage
from core.utils.webconnect import get_res_nbu, get_res_pb, get_res_sens
from core.utils.states import Steps
from core.keyboards.inline import get_choose_button
from core.settings import settings
from ..utils.dbconnect import DbRequests
from core.utils.fromtelethon import get_res_point
from core.utils import sql

switch = 'sql'
pb = []
nbu = []
point = []
sens = []
up_pb = []
point = []
up_point = []
up_sens = []

async def create_pool():
        return await asyncpg.create_pool(user='r2admin', password='admin@123', database='sender', 
                        host='127.0.0.1', port='5432', command_timeout='60')

async def set_data(): # <-- add global variables to func
   global nbu
   global pb
   global point
   global sens
   global up_nbu
   global up_pb
   global up_nbu
   global up_sens
   bank = ['НБУ', 'Приват Банк', 'Обменка на Одесской', 'SENS Банк']
   value = [nbu, up_nbu, pb, up_pb, point, up_point, sens, up_sens, bank]
   return value


# DIALOG


async def get_start(message: Message, state: FSMContext, mybot: Bot):
   global switch
   pool_connect = await create_pool()
   request = DbRequests(pool_connect)

   if switch == 'psql':
      await getdata(request) # <-- get data to global variables from web and db
   else:
      await sqlgetdata() # SQL
   s_id = message.from_user.id
   await start_ms(s_id, mybot)
   await message.answer(f'Как часто хочешь получать рассылку?', reply_markup=get_choose_button())
   ss = message.from_user
   s = [ss.id, ss.is_bot, ss.first_name, ss.last_name, ss.username, ss.language_code]
   if switch == 'psql':
      await request.addallusers(s[0], s[1], s[2], s[3], s[4], s[5])
   else:
      await sql.sqladdallusers(s[0], s[1], s[2], s[3], s[4], s[5]) # SQL
   await state.set_state(Steps.get_sender)

async def get_sender(call: CallbackQuery, state: FSMContext, mybot: Bot):
   global switch
   pool_connect = await create_pool()
   request = DbRequests(pool_connect)

   if call.data == 'time':
      await call.message.answer(f'Получать рассылку раз в день. Ввести время получения рассылки (формаи: 24ч, 2 цифры (00))', reply_markup=None)
      await state.set_state(Steps.get_time)
   elif call.data == 'every':    
      await call.message.answer(f'Получать рассылку при каждом изменении курса (бот обновляется каждые 5 минут)')
      id = call.message.chat.id
      if switch == 'psql':
         await request.addeverymetod(id, '99')
      else:
         await sql.sqladdeverymetod(id, '99') # SQL
      await every_module(request, mybot) # <--- run every module

   await call.answer()

async def get_time(message: Message, mybot: Bot, state: FSMContext):
   global switch
   pool_connect = await create_pool()
   request = DbRequests(pool_connect)

   time = message.text
   id = message.from_user.id
   if switch == 'psql':
      await request.addtimemetod(id, time, 'waiting')
   else:
      await sql.sqladdtimemetod(id, time, 'waiting') # SQL
   await message.answer(f'Получать рассылку каждый день в {time} час(а)')
   await time_module(request, mybot) # <---- run time module
   await state.clear()



# MAIN ALGORITM


async def every_module(request, mybot): 
   global switch
   print('\nEVERY module START \n')
   if switch == 'psql':
      every_list = await request.upeverylist()
      await getdata(request)
   else:
      every_list = await sql.sqlupeverylist() # SQL
      await sqlgetdata() # SQL

   x = await set_data()
   if x[0] != x[1]: # compare ndu data (0-web, 1-db)
      if switch == 'psql':
         await addtodbnbu(request)
      else:
         await sqladdtodbnbu() # SQL
      try:
         for id_e in every_list:
            await every_ms_nbu(x, id_e, mybot)
            await asyncio.sleep(.05)
            print('\nEVERY module --> send NBU data')
      except Exception as e:
         print(e)
      
   if x[2] != x[3]: # compare pb data (2-web, 3-db)
      if switch == 'psql':
         await addtodbpb(request)
      else:
         await sqladdtodbpb() # SQL   
      try:
         for id_e in every_list:
            await every_ms_pb(x, id_e, mybot)
            print('\nEVERY module --> send PB data')
      except Exception as e:
            print(e)

   if x[4] != x[5]: # compare point data (4-web, 5-db)
      if switch == 'psql':
         await addtodbpoint(request)
      else:
         await sqladdtodbpoint() # SQL   
      try:
         for id_e in every_list:
            await every_ms_point(x, id_e, mybot) 
            print('\nEVERY module --> send Point data')
      except Exception as e:
            print(e)
   
   if x[6] != x[7]: # compare sens data (6-web, 7-db)
      if switch == 'psql':
         await addtodbsens(request)   
      else:
         await sqladdtodbsens() # SQL
      try:
         for id_e in every_list:
            await every_ms_sens(x, id_e, mybot) 
            print('\nEVERY module --> send SENS data')
      except Exception as e:
            print(e)
            
        



async def time_module(request, mybot):
   global switch
   print('\nTIME module START \n')
   t_val = datetime.now().strftime("%H")
   if switch == 'psql':
      time_list = await request.uptimelist(t_val)
   else:
      time_list = await sql.sqluptimelist(t_val) # SQL
   print(f'time_list {time_list} and t_val {t_val}')
   if t_val == '00':
      if switch == 'psql':
         await request.updatewaitingtime()
      else:
         await sql.sqlupdatewaitingtime() # SQL
   x = await set_data()
   try:
      for id_t in time_list: 
         await time_ms(x, id_t, mybot)
         if switch == 'psql':
            await request.updatesendtime(id_t)
         else:
            await sql.sqlupdatesendtime(id_t) # SQL
         print('\nTIME module --> send result')
   except Exception as e:
         print(e)




# ANSWERS
#---- send answer START
async def start_ms(s_id, mybot):
   x = await set_data()
   t = datetime.now().strftime('%d.%m.%Y  %H:%M')
   text = (f'Сегодня: {t} \nКурс валют USD на сегодня \n \
          \n{x[0][0]} / {x[0][1]}    {x[8][0]} \
          \n{x[2][0]} / {x[2][1]}    {x[8][1]} \
          \n{x[6][0]} / {x[6][1]}    {x[8][3]} \
          \n{x[4][0]} / {x[4][1]}    {x[8][2]}')
   await mybot.send_message(s_id, text)
   print(f'\nANSWER \nSEND answer on START \n')


#---- send answer TIME
async def time_ms(x, id_t, mybot):
   t = datetime.now().strftime('%d.%m.%Y  %H:%M')
   text = (f'Сегодня: {t} \nКурс валют USD на сегодня \n \
          \n{x[0][0]} / {x[0][1]}    {x[8][0]} \
          \n{x[2][0]} / {x[2][1]}    {x[8][1]} \
          \n{x[6][0]} / {x[6][1]}    {x[8][3]} \
          \n{x[4][0]} / {x[4][1]}    {x[8][2]}')
   await mybot.send_message(id_t, text)
   print(f'\nANSWER \nSEND answer to USER time \n')

#---- send answer EVERY NBU
async def every_ms_nbu(x, id_e, mybot):
   t = datetime.now().strftime('%d.%m.%Y  %H:%M')
   text = (f'Обновление {t} \n \
          \n{x[0][0]} / {x[0][1]}    {x[8][0]}\n  \
          \nКурс валют USD на сегодня \n \
          \n{x[0][0]} / {x[0][1]}    {x[8][0]} \
          \n{x[2][0]} / {x[2][1]}    {x[8][1]} \
          \n{x[6][0]} / {x[6][1]}    {x[8][3]} \
          \n{x[4][0]} / {x[4][1]}    {x[8][2]}')
   await mybot.send_message(id_e, text)
   print(f'\nANSWER \nSEND answer to USER every NBU \n')

#---- send answer EVERY PB
async def every_ms_pb(x, id_e, mybot):
   v_ide = id_e
   t = datetime.now().strftime('%d.%m.%Y  %H:%M')
   text = (f'Обновление {t} \n \
          \n{x[2][0]} / {x[2][1]}    {x[8][1]}\n \
          \nКурс валют USD на сегодня \n \
          \n{x[0][0]} / {x[0][1]}    {x[8][0]} \
          \n{x[2][0]} / {x[2][1]}    {x[8][1]} \
          \n{x[6][0]} / {x[6][1]}    {x[8][3]} \
          \n{x[4][0]} / {x[4][1]}    {x[8][2]}')
   await mybot.send_message(v_ide, text)
   print(f'\nANSWER \nSEND answer to USER every PB \n')

#---- send answer EVERY SENS
async def every_ms_sens(x, id_e, mybot):
   v_ide = id_e
   t = datetime.now().strftime('%d.%m.%Y  %H:%M')
   text = (f'Обновление {t} \n \
          \n{x[6][0]} / {x[6][1]}    {x[8][3]} \n \
          \nКурс валют USD на сегодня \n \
          \n{x[0][0]} / {x[0][1]}    {x[8][0]} \
          \n{x[2][0]} / {x[2][1]}    {x[8][1]} \
          \n{x[6][0]} / {x[6][1]}    {x[8][3]} \
          \n{x[4][0]} / {x[4][1]}    {x[8][2]}')
   await mybot.send_message(v_ide, text)
   print(f'\nANSWER \nSEND answer to USER every SENS \n')

#---- send answer EVERY Point
async def every_ms_point(x, id_e, mybot):
   v_ide = id_e
   t = datetime.now().strftime('%d.%m.%Y  %H:%M')
   text = (f'Обновление {t} \n \
          \n{x[4][0]} / {x[4][1]}    {x[8][2]} \n \
          \nКурс валют USD на сегодня \n \
          \n{x[0][0]} / {x[0][1]}    {x[8][0]} \
          \n{x[2][0]} / {x[2][1]}    {x[8][1]} \
          \n{x[6][0]} / {x[6][1]}    {x[8][3]} \
          \n{x[4][0]} / {x[4][1]}    {x[8][2]}')
   await mybot.send_message(v_ide, text)
   print(f'\nANSWER \nSEND answer to USER every Point \n')

### FOR RUN ANSWER

# x = await set_data()
# await time_ms(message, x)
# await every_ms_nbu(message, x)
# await every_ms_pb(message, x)



# REQUEST

#-----requests get data from web and db --> PSQL
async def getdata(request):
   global pb
   global nbu
   global point
   global sens
   global up_nbu
   global up_pb
   global up_point
   global up_sens
   global switch
   #get data from web
   nbu = await get_res_nbu()
   pb = await get_res_pb()
   point = await get_res_point()
   sens = await get_res_sens()
   #get data from bd
   up_nbu = await request.up_nbu_data(1, 'buy', 'sale')
   up_pb = await request.up_pb_data(2, 'buy', 'sale')
   up_point = await request.up_point_data(3, 'buy', 'sale')
   up_sens = await request.up_sens_data(4, 'buy', 'sale')
   
   print(f'\nREQUEST \nGET data from WEB and DB \n{switch} \nweb: {nbu} and {pb} and {point} and {sens} \
         \ntab: {up_nbu} and {up_pb} and {up_point} and {up_sens}\nIF not NULL = OK \n')

#-----requests get data from web and db --> SQL
async def sqlgetdata():
   global pb
   global nbu
   global point
   global sens
   global up_nbu
   global up_pb
   global up_point
   global up_sens
   global switch
   #get data from web
   nbu = await get_res_nbu()
   pb = await get_res_pb()
   point = await get_res_point()
   sens = await get_res_sens()
   #get data from bd
   up_nbu = await sql.sql_up_nbu_data(1, 'buy', 'sale') # SQL
   up_pb = await sql.sql_up_pb_data(2, 'buy', 'sale') # SQL
   up_point = await sql.sql_up_point_data(3, 'buy', 'sale') # SQL
   up_sens = await sql.sql_up_sens_data(4, 'buy', 'sale') # SQL
   print(f'\nREQUEST SQL \nGET data from WEB and DB \n{switch} \nweb: {nbu} and {pb} and {point} and {sens} \
         \ntab: {up_nbu} and {up_pb} and {up_point} and {up_sens}\nIF not NULL = OK \n')


# ADD DATA TO DB

#add data to db NBU
async def addtodbnbu(request):
   global nbu
   buy_nbu: float = nbu[0]
   sale_nbu:float = nbu[1]
   await request.add_pars_data(1, buy_nbu, sale_nbu)
   print(f'\nREQUEST \nADD data to DB NBU \n')

async def sqladdtodbnbu():
   global nbu
   buy_nbu: float = nbu[0]
   sale_nbu:float = nbu[1]
   await sql.sql_add_pars_data('1', buy_nbu, sale_nbu)
   print(f'\nREQUEST \nADD data to DB NBU --> SQL\n')

#add data to db PB
async def addtodbpb(request):
   global pb
   buy_pb: float = pb[0]
   sale_pb:float = pb[1]
   await request.add_pars_data(2, buy_pb, sale_pb)
   print(f'\nREQUEST \nADD data to DB PB \n')

async def sqladdtodbpb():
   global pb
   buy_pb: float = pb[0]
   sale_pb:float = pb[1]
   await sql.sql_add_pars_data('2', buy_pb, sale_pb)
   print(f'\nREQUEST \nADD data to DB PB --> SQL\n')

#add data to db Point
async def addtodbpoint(request):
   global point
   buy_point: float = point[0]
   sale_point:float = point[1]
   await request.add_pars_data(3, buy_point, sale_point)
   print(f'\nREQUEST \nADD data to DB Point \n')

async def sqladdtodbpoint():
   global point
   buy_point: float = point[0]
   sale_point:float = point[1]
   await sql.sql_add_pars_data('3', buy_point, sale_point)
   print(f'\nREQUEST \nADD data to DB Point --> SQL\n')

#add data to db SENS
async def addtodbsens(request):
   global sens
   buy_sens: float = sens[0]
   sale_sens: float = sens[1]
   await request.add_pars_data(4, buy_sens, sale_sens)
   print(f'\nREQUEST \nADD data to DB SENS \n')

async def sqladdtodbsens():
   global sens
   buy_sens: float = sens[0]
   sale_sens: float = sens[1]
   await sql.sql_add_pars_data('4', buy_sens, sale_sens)
   print(f'\nREQUEST \nADD data to DB SENS --> SQL\n')










   
  



   

    
    
