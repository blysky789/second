from aiogram.utils.keyboard import InlineKeyboardBuilder

def get_choose_button():
    keyboard_builder=InlineKeyboardBuilder()
    keyboard_builder.button(text='Получать рассылку раз в день в указаное время', callback_data='time')
    keyboard_builder.button(text='Получать каждое обновление курса', callback_data='every')
    keyboard_builder.adjust(1)
    return keyboard_builder.as_markup()